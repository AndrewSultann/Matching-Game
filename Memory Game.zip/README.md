# Matching-Game
-The game is simple, you need to match all pairs of cards with least number of tries.
You have a timer and you are getting rated at the end of the game depends on the number of your tries.
-For Download : Go to https://github.com/AndrewSultann/Matching-Game
Open The index.html file and start playing !!

